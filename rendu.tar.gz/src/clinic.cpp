#include "clinic.h"
#include "costs.h"
#include <pcosynchro/pcothread.h>
#include <iostream>
#include <random>

#include "hospital.h"

Clinic::Clinic(int id, int fund, std::vector<ItemType> resourcesNeeded)
: Seller(fund, id), resourcesNeeded(std::move(resourcesNeeded)) {
    for (auto it : this->resourcesNeeded) {
        stocks[it] = 0;
    }

    stocks[ItemType::SickPatient] = 0;
    stocks[ItemType::RehabPatient] = 0;
}

void Clinic::run() {
    logger() << "Clinic " <<  uniqueId << " starting with fund " << money << std::endl;

    while (true) {
        clock->worker_wait_day_start();
        if (PcoThread::thisThread()->stopRequested()) break;

        // Essayer de traiter le prochain patient
        processNextPatient();

        // Transférer les patients déjà traités vers un hôpital pour leur réhabilitation
        sendPatientsToRehab();

        // Payer les factures en retard
        payBills();

        clock->worker_end_day();
    }

    logger() << "Clinic " <<  uniqueId << " stopping with fund " << money << std::endl;
}


int Clinic::transfer(ItemType what, int qty) {

    if (what != ItemType::SickPatient) return 0;

    // si on a pas de facture et de l'argent
    if (unpaidBills.empty() && money > 0) {

        // trouver combien on peut en accepter suivant le coût de traitement
        int endQty = qty;
        while (endQty * getCostPerService(ServiceType::Treatment) < 0) { --endQty; }

        // ajouter le nombre de nouveaux patients
        patientsMutex.lock();
        stocks[ItemType::SickPatient] += endQty;
        patientsMutex.unlock();

        // retourner le nombre de patients acceptés
        return endQty;
    }

    // sinon retourner 0 patients acceptés
    return 0;
}

bool Clinic::hasResourcesForTreatment() const {

    // tourner sur toutes les ressources vérifier qu'on en ait 1 de chaque
    bool hasResources = true;
    for (const auto& item : resourcesNeeded)
        if (stocks.at(item) < 1)
            hasResources = false;

    // retourner le résultat
    return hasResources;
}

bool Clinic::hasMoneyForTreatment() const {
    return (money - getEmployeeSalary(EmployeeType::TreatmentSpecialist)) >= 0;
}

void Clinic::payBills() {

    // tourner sur toutes les factures
    auto bill = unpaidBills.begin();
    while (bill != unpaidBills.end()) {

        // si on peut la payer
        moneyMutex.lock();
        if (bill->second <= money) {

            // enlever l'argent
            money -= bill->second;
            moneyMutex.unlock();

            // payer la facture
            bill->first->pay(bill->second);

            // supprimer l'ancienne facture
            bill = unpaidBills.erase(bill);

        } else {
            moneyMutex.unlock();
            ++bill;
        }
    }
}

void Clinic::processNextPatient() {

    // vérifier qu'on a des patients
    if (stocks[ItemType::SickPatient] < 1)
        return;

    // commander le matériel nécessaire
    orderResources();

    // traiter le patient
    treatOne();
}

void Clinic::sendPatientsToRehab() {
    // si on a plus de patients arrêter
    if (stocks[ItemType::RehabPatient]) {

        auto *hospital = chooseRandomSeller(hospitals);

        // demander à l'hôpital et enregistrer le nombre de patients acceptés
        patientsMutex.lock();
        const int nbAccepted = hospital->transfer(ItemType::RehabPatient, stocks[ItemType::RehabPatient]);
        stocks[ItemType::RehabPatient] -= nbAccepted;
        patientsMutex.unlock();

        // envoyer la facture à l'assurance
        insurance->invoice(nbAccepted * getCostPerService(ServiceType::Treatment), this);
    }
}

void Clinic::orderResources() {
    // si on a besoin de l'item
    for (const auto& item : resourcesNeeded) {
        if (stocks.at(item) < 1) {

            // choisir un supplier qui a la ressource
            auto *supplier = chooseRandomSupplier(item);

            // on laisse cette ligne au cas ou on veut commander plus que 1
            if (int price = supplier->buy(item, 1); price > 0) {
                stocks[item] += 1;
                unpaidBills.emplace_back(dynamic_cast<Supplier *>(supplier), price);
            }
        }
    }
}

void Clinic::treatOne() {

    moneyMutex.lock();
    patientsMutex.lock();
    if (hasMoneyForTreatment() && hasResourcesForTreatment()) {

        // enlever un item de chaque
        for (ItemType item : resourcesNeeded)
            --stocks[item];

        // guérir le patient
        --stocks[ItemType::SickPatient];
        ++stocks[ItemType::RehabPatient];

        // payer le spécialiste
        money -= getEmployeeSalary(EmployeeType::TreatmentSpecialist);
        ++nbEmployeesPaid;
    }
    patientsMutex.unlock();
    moneyMutex.unlock();
}

void Clinic::pay(int bill) {
    moneyMutex.lock();
    money += bill;
    moneyMutex.unlock();
}

Supplier *Clinic::chooseRandomSupplier(ItemType item) {
    std::vector<Supplier*> availableSuppliers;

    // Sélectionner les Suppliers qui ont la ressource recherchée
    for (Seller* seller : suppliers) {
        auto* sup = dynamic_cast<Supplier*>(seller);
        if (sup->sellsResource(item)) {
            availableSuppliers.push_back(sup);
        }
    }

    // Choisir aléatoirement un Supplier dans la liste
    assert(availableSuppliers.size());
    std::vector<Supplier*> out;
    std::sample(availableSuppliers.begin(), availableSuppliers.end(), std::back_inserter(out),
            1, std::mt19937{std::random_device{}()});
    return out.front();
}

void Clinic::setHospitalsAndSuppliers(std::vector<Seller*> hospitals, std::vector<Seller*> suppliers) {
    this->hospitals = hospitals;
    this->suppliers = suppliers;
}

void Clinic::setInsurance(Seller* ins) { 
    insurance = ins; 
}


int Clinic::getTreatmentCost() {
    return 0;
}

int Clinic::getWaitingPatients() {
    return stocks[ItemType::SickPatient];
}

int Clinic::getNumberPatients() {
    return stocks[ItemType::SickPatient] + stocks[ItemType::RehabPatient];
}

Pulmonology::Pulmonology(int uniqueId, int fund) :
    Clinic::Clinic(uniqueId, fund, {ItemType::Pill, ItemType::Thermometer}) {}

Cardiology::Cardiology(int uniqueId, int fund) :
    Clinic::Clinic(uniqueId, fund, {ItemType::Syringe, ItemType::Stethoscope}) {}

Neurology::Neurology(int uniqueId, int fund) :
    Clinic::Clinic(uniqueId, fund, {ItemType::Pill, ItemType::Scalpel}) {}
